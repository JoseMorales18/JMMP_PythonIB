"Menu de Estados casos Covid"

import json
from tkinter import *
from tkinter.ttk import *

ags={}
ags['Casos']=[]
ags['Casos'].append({
    'Confirmados':7270,'Negativos':14407,
    'Sospechosos':915,'Defunciones':630,
    'Recuperados':5043,'Activos':301
    })
BC={}
BC['Casos']=[]
BC['Casos'].append({
    'Confirmados':19510,'Negativos':12040,
    'Sospechosos':1612,'Defunciones':3586,
    'Recuperados':12482,'Activos':298
    })
BCS={}
BCS['Casos']=[]
BCS['Casos'].append({
    'Confirmados':10341,'Negativos':14113,
    'Sospechosos':516,'Defunciones':469,
    'Recuperados':8461,'Activos':641
    })
Camp={}
Camp['Casos']=[]
Camp['Casos'].append({
    'Confirmados':5982,'Negativos':7043,
    'Sospechosos':142,'Defunciones':820,
    'Recuperados':4014,'Activos':55
    })
Chis={}
Chis['Casos']=[]
Chis['Casos'].append({
    'Confirmados':6552,'Negativos':5209,
    'Sospechosos':211,'Defunciones':1090,
    'Recuperados':4039,'Activos':51
    })
def Estado():
    if combo.get()=='Aguascalientes':
        print("Estos son los casos en Aguascalietes:")
        print(ags['Casos'])
        print(" ")
    elif combo.get()=='Baja California Norte':
        print("Estos son los casos en Baja California Norte:")
        print(BC['Casos'])
        print(" ")
    elif combo.get()=='Baja California Sur':
        print("Estos son los casos en Baja California Sur:")
        print(BCS['Casos'])
        print(" ")
    elif combo.get()=='Campeche':
        print("Estos son los casos en Campeche:")
        print(Camp['Casos'])
        print(" ")
    else:
        print("Estos son los casos en Chiapas:")
        print(Chis['Casos'])
        print(" ")
def guardar():
    if combo.get()=='Aguascalientes':
        with open('agscovid.json','w') as file:
            json.dump(ags,file)
    elif combo.get()=='Baja California Norte':
        with open('BCcovid.json','w') as file:
            json.dump(BC,file)
    elif combo.get()=='Baja California Sur':
        with open('BCScovid.json','w') as file:
            json.dump(BCS,file)
    elif combo.get()=='Campeche':
        with open('Campcovid.json','w') as file:
            json.dump(Camp,file)
    else:
        with open('Chiscovid.json','w') as file:
            json.dump(Chis,file)
    print("Los datos  han sido guardados correctamente")
    
windows=Tk()
windows.title('Menu de Estados')
windows.geometry('350x200')

texto=StringVar()
texto.set("Estado: ")

combo=Combobox(windows)
combo.place(x=100,y=50)
combo['value']=('Aguascalientes','Baja California Norte','Baja California Sur','Campeche','Chiapas')
combo.current()

boton=Button(windows,command=guardar,text="Guardar Datos")
btn=Button(windows,command=Estado,text="Entrar")
eti=Label(windows,textvariable=texto)
eti.place(x=100,y=100)

boton.place(x=175,y=150)
btn.place(x=75,y=150)

windows.mainloop()
input(" ")


